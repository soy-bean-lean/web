### Hi there ! 👋😄

**Here are some ideas to get you started:**

- 🔭 I’m currently working on Deep Learning + Cyber Secuirty.
- 🌱 I’m currently learning AI Python, Pytorch.
- 👯 I’m looking to collaborate on Kaggle and Research-based projects.
- 💬 Ask me about *Python*.
- 2021 Goals : Contribute to more open source projects, Release a pip package, Go in depth in to AI, Blockchain and CyberSecurity..
- ⚡ Fun fact: Sometimes i wanna be happy without doing nothing
<!---- 🤔 I’m looking for help with [Stacked Hourglass Network](https://arxiv.org/abs/1603.06937#:~:text=We%20refer%20to%20the%20architecture,benchmarks%20outcompeting%20all%20recent%20methods.), [JPP-Net](https://arxiv.org/pdf/1804.01984).-->
- 📫 How to reach me: rsnramasinghe@gmail.com
😄 Pronouns: Anything you like.
<!--- - ⚡ Fun fact: Undergrad in ECE but don't know why I chose that.  -->

![Rishie's GitHub stats](https://github-readme-stats.vercel.app/api?username=rishier827&show_icons=true&theme=radical)
<img align='right' src='https://github.com/Rishit-dagli/Rishit-dagli/blob/master/images/octocat-anime.gif' width='200"'>  
<!-- [![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=rishier827&layout=compact)](https://github.com/rishier827/github-readme-stats) -->
<hr>
<br>

<p align = "center"><b>You can find me here</b></p>
<p align = "center"><img align="center" src="https://github.com/rajput2107/rajput2107/blob/master/Assets/Handshake.gif" height="33px" /></p>
<!--<p align = "center"><a><img src="https://icon-library.net//images/icon-programmer/icon-programmer-14.jpg" width="150px" height="150px" /></a></p>  -->
<p align = "center"><a href="https://www.linkedin.com/in/nishara-ramasinghe-7976ab15a/"><img src="https://github.com/hussainweb/hussainweb/blob/main/icons/linkedin.png" width="32px" height="32px"></a>  <a href="https://medium.com/@rsnramasinghe"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/medium.svg" width="32px" height="32px"></a>  </p>  
  
**Visitors Count**  
![VisitorCount](https://profile-counter.glitch.me/{rishier827}/count.svg)
<!-- https://cdn4.iconfinder.com/data/icons/logos-and-brands/512/189_Kaggle_logo_logos-512 -->

<hr>

<br>

<img align="center" alt="GIF" src="https://github.com/abhisheknaiidu/abhisheknaiidu/blob/master/code.gif?raw=true" width="500" height="320" />

<br>
